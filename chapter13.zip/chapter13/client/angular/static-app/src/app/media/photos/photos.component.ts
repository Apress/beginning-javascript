import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../services/service.service';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.sass']
})
export class PhotosComponent implements OnInit {

  constructor( private service: ServiceService) { }

public photoResults;

  ngOnInit() {
    this.service.getPhotos().subscribe( (results) => {
      this.photoResults = results;
    });
  }

}
