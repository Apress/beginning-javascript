import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BoroughsModule } from './boroughs/boroughs.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BoroughsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
