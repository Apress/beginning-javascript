import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-boroughs',
  templateUrl: './list-boroughs.component.html',
  styleUrls: ['./list-boroughs.component.sass']
})
export class ListBoroughsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
