import { Component, OnInit } from '@angular/core';
import { BoroughService } from '../../service/borough/borough.service';

@Component({
  selector: 'app-list-boroughs',
  templateUrl: './list-boroughs.component.html',
  styleUrls: ['./list-boroughs.component.sass']
})
export class ListBoroughsComponent implements OnInit {

  constructor(private boroughService: BoroughService) { }

  ngOnInit() {
    this.boroughService.getBoroughts().subscribe( (data) => {
      console.log(data)
    });
  }

}
