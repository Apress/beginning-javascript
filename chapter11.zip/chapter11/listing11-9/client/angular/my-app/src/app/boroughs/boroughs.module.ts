import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListBoroughsComponent } from './list-boroughs/list-boroughs.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [ListBoroughsComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [ListBoroughsComponent]
})
export class BoroughsModule { }
