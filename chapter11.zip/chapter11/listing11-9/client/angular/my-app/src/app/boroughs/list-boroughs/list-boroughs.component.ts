import { Component, OnInit } from '@angular/core';
import { BoroughService } from '../../service/borough/borough.service';
import { Borough } from '../model/borough';

@Component({
  selector: 'app-list-boroughs',
  templateUrl: './list-boroughs.component.html',
  styleUrls: ['./list-boroughs.component.sass']
})
export class ListBoroughsComponent implements OnInit {
  private results: any;
  private model: Borough = new Borough();

  constructor(private boroughService: BoroughService) { }

  ngOnInit() {
    this.boroughService.getBoroughts().subscribe( (data) => {
      this.results = data;
    });
  }

  submitForm(value){
    //console.log(value);
    this.boroughService.addBorough(value).subscribe((results) => {
      console.log(results);
    });
  }

}
