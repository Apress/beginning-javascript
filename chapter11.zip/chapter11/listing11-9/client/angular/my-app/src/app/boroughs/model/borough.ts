export class Borough {

  public boroughName: string;
  public state: string;
  constructor() {

  }
}
