import { Borough } from './borough';

describe('Borough', () => {
  it('should create an instance', () => {
    expect(new Borough()).toBeTruthy();
  });
});
